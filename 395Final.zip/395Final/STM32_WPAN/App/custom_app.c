/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    App/custom_app.c
  * @author  MCD Application Team
  * @brief   Custom Example Application (Server)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "app_common.h"
#include "dbg_trace.h"
#include "ble.h"
#include "custom_app.h"
#include "custom_stm.h"
#include "stm32_seq.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef struct
{
  /* P2P_Server */
  /* HR_long */
  uint8_t               Hr_m_Notification_Status;
  /* USER CODE BEGIN CUSTOM_APP_Context_t */

  /* USER CODE END CUSTOM_APP_Context_t */

  uint16_t              ConnectionHandle;
} Custom_App_Context_t;

/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private defines ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macros -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/**
 * START of Section BLE_APP_CONTEXT
 */

static Custom_App_Context_t Custom_App_Context;

/**
 * END of Section BLE_APP_CONTEXT
 */

uint8_t UpdateCharData[247];
uint8_t NotifyCharData[247];

/* USER CODE BEGIN PV */
uint8_t unlocked_before = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* P2P_Server */
/* HR_long */
static void Custom_Hr_m_Update_Char(void);
static void Custom_Hr_m_Send_Notification(void);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Functions Definition ------------------------------------------------------*/
void Custom_STM_App_Notification(Custom_STM_App_Notification_evt_t *pNotification)
{
  /* USER CODE BEGIN CUSTOM_STM_App_Notification_1 */

  /* USER CODE END CUSTOM_STM_App_Notification_1 */
  switch (pNotification->Custom_Evt_Opcode)
  {
    /* USER CODE BEGIN CUSTOM_STM_App_Notification_Custom_Evt_Opcode */

    /* USER CODE END CUSTOM_STM_App_Notification_Custom_Evt_Opcode */

    /* P2P_Server */
    case CUSTOM_STM_ICARD_NO_READ_EVT:
      /* USER CODE BEGIN CUSTOM_STM_ICARD_NO_READ_EVT */

      /* USER CODE END CUSTOM_STM_ICARD_NO_READ_EVT */
      break;

    case CUSTOM_STM_ICARD_NO_WRITE_NO_RESP_EVT:
      /* USER CODE BEGIN CUSTOM_STM_ICARD_NO_WRITE_NO_RESP_EVT */
    	APP_DBG_MSG("\r\n\r** ICard Number Received \n");
//	  APP_DBG_MSG("\r\n\r** Write Data: 0x%02X %02X \n", pNotification->DataTransfered.pPayload[0], pNotification->DataTransfered.pPayload[1]);
    	if (pNotification->DataTransfered.pPayload[0] == 0x42){
    		APP_DBG_MSG("\r\n\r** ICard Accepted \n");
    		HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_0);
    		HAL_GPIO_TogglePin (GPIOA, GPIO_PIN_12);
    		HAL_Delay (1000);   /* Insert delay 2000 ms */
    		APP_DBG_MSG("\r\n\r** Door Unlocked \n");
    		HAL_GPIO_TogglePin (GPIOA, GPIO_PIN_12);
//    		HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_0);
    		HAL_Delay(3000);
    		HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_0);
    		HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_1);
			HAL_GPIO_TogglePin (GPIOA, GPIO_PIN_11);
			HAL_Delay (1000);   /* Insert delay 2000 ms */
			APP_DBG_MSG("\r\n\r** Door Locked \n");
			HAL_GPIO_TogglePin (GPIOA, GPIO_PIN_11);
			HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_1);
			unlocked_before = 1;
//			APP_DBG_MSG("\r\n\r** Door Locked \n");
    	} else{
    		APP_DBG_MSG("\r\n\r** ICard Rejected \n");
    		HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_1);
			HAL_Delay (2000);   /* Insert delay 1000 ms */
			HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_1);
			APP_DBG_MSG("\r\n\r** Try Again \n");
    	}
      /* USER CODE END CUSTOM_STM_ICARD_NO_WRITE_NO_RESP_EVT */
      break;

    /* HR_long */
    case CUSTOM_STM_HR_M_NOTIFY_ENABLED_EVT:
      /* USER CODE BEGIN CUSTOM_STM_HR_M_NOTIFY_ENABLED_EVT */

      /* USER CODE END CUSTOM_STM_HR_M_NOTIFY_ENABLED_EVT */
      break;

    case CUSTOM_STM_HR_M_NOTIFY_DISABLED_EVT:
      /* USER CODE BEGIN CUSTOM_STM_HR_M_NOTIFY_DISABLED_EVT */

      /* USER CODE END CUSTOM_STM_HR_M_NOTIFY_DISABLED_EVT */
      break;

    default:
      /* USER CODE BEGIN CUSTOM_STM_App_Notification_default */

      /* USER CODE END CUSTOM_STM_App_Notification_default */
      break;
  }
  /* USER CODE BEGIN CUSTOM_STM_App_Notification_2 */

  /* USER CODE END CUSTOM_STM_App_Notification_2 */
  return;
}

void Custom_APP_Notification(Custom_App_ConnHandle_Not_evt_t *pNotification)
{
  /* USER CODE BEGIN CUSTOM_APP_Notification_1 */

  /* USER CODE END CUSTOM_APP_Notification_1 */

  switch (pNotification->Custom_Evt_Opcode)
  {
    /* USER CODE BEGIN CUSTOM_APP_Notification_Custom_Evt_Opcode */

    /* USER CODE END P2PS_CUSTOM_Notification_Custom_Evt_Opcode */
    case CUSTOM_CONN_HANDLE_EVT :
      /* USER CODE BEGIN CUSTOM_CONN_HANDLE_EVT */

      /* USER CODE END CUSTOM_CONN_HANDLE_EVT */
      break;

    case CUSTOM_DISCON_HANDLE_EVT :
      /* USER CODE BEGIN CUSTOM_DISCON_HANDLE_EVT */

      /* USER CODE END CUSTOM_DISCON_HANDLE_EVT */
      break;

    default:
      /* USER CODE BEGIN CUSTOM_APP_Notification_default */

      /* USER CODE END CUSTOM_APP_Notification_default */
      break;
  }

  /* USER CODE BEGIN CUSTOM_APP_Notification_2 */

  /* USER CODE END CUSTOM_APP_Notification_2 */

  return;
}

void Custom_APP_Init(void)
{
  /* USER CODE BEGIN CUSTOM_APP_Init */

  /* USER CODE END CUSTOM_APP_Init */
  return;
}

/* USER CODE BEGIN FD */

/* USER CODE END FD */

/*************************************************************
 *
 * LOCAL FUNCTIONS
 *
 *************************************************************/

/* P2P_Server */
/* HR_long */
void Custom_Hr_m_Update_Char(void) /* Property Read */
{
  uint8_t updateflag = 0;

  /* USER CODE BEGIN Hr_m_UC_1*/

  /* USER CODE END Hr_m_UC_1*/

  if (updateflag != 0)
  {
    Custom_STM_App_Update_Char(CUSTOM_STM_HR_M, (uint8_t *)UpdateCharData);
  }

  /* USER CODE BEGIN Hr_m_UC_Last*/

  /* USER CODE END Hr_m_UC_Last*/
  return;
}

void Custom_Hr_m_Send_Notification(void) /* Property Notification */
{
  uint8_t updateflag = 0;

  /* USER CODE BEGIN Hr_m_NS_1*/

  /* USER CODE END Hr_m_NS_1*/

  if (updateflag != 0)
  {
    Custom_STM_App_Update_Char(CUSTOM_STM_HR_M, (uint8_t *)NotifyCharData);
  }

  /* USER CODE BEGIN Hr_m_NS_Last*/

  /* USER CODE END Hr_m_NS_Last*/

  return;
}

/* USER CODE BEGIN FD_LOCAL_FUNCTIONS*/

/* USER CODE END FD_LOCAL_FUNCTIONS*/
